#ifndef SCC_CONFIG_H_
#define SCC_CONFIG_H_

#define SCC_THRESHOLD 3

#endif /* SCC_CONFIG_H_ */
